using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using AfSdr.Dsp;

namespace AfSdr;

// UI-thread-owned ring bitmap: one new scan line per fresh displayed FFT frame.
internal sealed class WaterfallHistory : IDisposable
{
    private static readonly Color[] Stops = [Color.FromArgb(8, 13, 26), Color.FromArgb(22, 39, 106),
        Color.FromArgb(0, 146, 190), Color.FromArgb(69, 215, 140),
        Color.FromArgb(255, 217, 66), Color.FromArgb(255, 80, 38)];
    internal const int Capacity = 300;
    private Bitmap bitmap = new(SpectrumProcessor.DefaultSize, Capacity * 2, PixelFormat.Format32bppArgb);
    private int[] row = new int[SpectrumProcessor.DefaultSize];
    private readonly float[]?[] levels = new float[Capacity][];
    private float minimum = -120, maximum = 0;
    private int head;
    internal int Count { get; private set; }

    internal void Add(float[] values)
    {
        if (values.Length != row.Length)
        {
            if (!SpectrumProcessor.SupportedSizes.Contains(values.Length)) throw new ArgumentException("Unexpected FFT size.");
            var replacement = new Bitmap(values.Length, Capacity * 2, PixelFormat.Format32bppArgb);
            bitmap.Dispose();
            bitmap = replacement;
            row = new int[values.Length];
            Clear();
        }
        head = (head + Capacity - 1) % Capacity;
        levels[head] = (float[])values.Clone();
        WriteRow(head, values);
        Count = Math.Min(Count + 1, Capacity);
    }

    private void WriteRow(int target, float[] values)
    {
        for (int i = 0; i < row.Length; i++) row[i] = LevelColor(values[i], minimum, maximum).ToArgb();
        // Mirror each ring row: any head now exposes one contiguous chronological region.
        foreach (int y in new[] { target, target + Capacity })
        {
            var data = bitmap.LockBits(new Rectangle(0, y, row.Length, 1), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
            try { Marshal.Copy(row, 0, data.Scan0, row.Length); }
            finally { bitmap.UnlockBits(data); }
        }
    }

    internal void SetLevels(float lower, float upper)
    {
        if (!float.IsFinite(lower) || !float.IsFinite(upper) || upper <= lower) throw new ArgumentException("Invalid level range.");
        if (minimum == lower && maximum == upper) return;
        minimum = lower; maximum = upper;
        for (int i = 0; i < Capacity; i++) if (levels[i] is { } values) WriteRow(i, values);
    }

    internal static Color LevelColor(float db, float lower = -120, float upper = 0)
    {
        float value = Math.Clamp((db - lower) / (upper - lower), 0, 1) * (Stops.Length - 1);
        int index = Math.Min((int)value, Stops.Length - 2);
        float part = value - index;
        Color a = Stops[index], b = Stops[index + 1];
        return Color.FromArgb((int)(a.R + (b.R - a.R) * part),
            (int)(a.G + (b.G - a.G) * part), (int)(a.B + (b.B - a.B) * part));
    }

    internal void Draw(Graphics graphics, RectangleF target, DisplayRange? range = null)
    {
        if (Count == 0) return;
        float sourceX = (float)(range?.FirstBin(bitmap.Width) ?? 0);
        float sourceWidth = (float)(range?.BinWidth(bitmap.Width) ?? bitmap.Width);
        // One scaling transform avoids sampling-phase changes at a moving wrap seam.
        graphics.DrawImage(bitmap, new RectangleF(target.X, target.Y, target.Width, target.Height * Count / Capacity),
            new RectangleF(sourceX, head, sourceWidth, Count), GraphicsUnit.Pixel);
    }

    internal void Clear() { Count = 0; head = 0; Array.Clear(levels); }
    public void Dispose() => bitmap.Dispose();
}
